//
//  SwiftUIView.swift
//  
//
//  Created by Student10 on 25/09/23.
//

import SwiftUI

struct VisionDetailsView: View {
    @State var name: String = ""
    @State var info: String = ""
    @State var prevent: String = ""
    @State private var mostrarPrevent = false
    
    var body: some View {
        
        VStack{
            Spacer()
            ScrollView(showsIndicators: false) {
                Text(name)
                    .foregroundColor(.black)
                Text(info)
                    .padding()
                    .cornerRadius(4.0)
                    .padding(EdgeInsets(top: 0, leading: 0, bottom: 15, trailing: 0))
                    .foregroundColor(.black)
                Spacer()
                Button("Prevenção") {
                    mostrarPrevent.toggle()
                }
                .sheet(isPresented: $mostrarPrevent) {
                    Spacer()
                    ScrollView(showsIndicators: false) {
                        Text(prevent)
                            .padding()
                            .cornerRadius(4.0)
                            .padding(EdgeInsets(top: 0, leading: 0, bottom: 15, trailing: 0))
                            .font(.system(size: 20, design: .serif))
                    }.foregroundColor(.black)
                        .background(Color(.white))
                    Spacer()
                }
            }
            
            
        }.background(Color("Color1"))
            .font(.system(size: 18, design: .serif))
            .frame(maxWidth: .infinity, alignment: .leading)
            
        
    }
}




struct VisionDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        VisionDetailsView()
    }
}

