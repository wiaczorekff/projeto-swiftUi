/*
 See the License.txt file for this sample’s licensing information.
 */

import SwiftUI

struct CameraView: View {
    @StateObject private var model = DataModel()
    
    @State private var selectedFilter = ""
    @State private var blurAmount = 0.0
    @State private var conditionAmount = 0.0
    
    private static let barHeightFactor = 0.30
    
    struct VisualDisease: Identifiable {
        var id = UUID()
        var name: String
        var info: String
        var prevent: String
        
    }
    
    var arrayVisualDiseases = [
        VisualDisease(name: "Astigmatismo", info: "\n • O astigmatismo não é uma doença, é mais como uma pequena diferença na forma dos olhos. Pense nisso como se fosse um pedacinho da sua janela que não está perfeitamente liso. Por causa dessa pequena irregularidade na sua janela (ou córnea, no caso dos olhos), a luz que entra nos seus olhos se espalha e vai parar em lugares diferentes na sua tela da retina. \n\n • Isso faz com que as imagens que você vê fiquem um pouco confusas, borradas ou até um pouco estranhas, como se as coisas estivessem distorcidas. Mas não se preocupe, muitas pessoas têm astigmatismo, e é algo que os médicos podem corrigir com óculos ou lentes de contato. Eles ajudam a endireitar a luz para que as imagens fiquem nítidas e bonitas novamente!", prevent:"DICAS \n • Nem sempre é possível prevenir. Muitas vezes o problema está ligado ao histórico familiar. \n\n • Outra razão frequente – e que pode ser combatida – é o hábito de coçar o olho. Especialmente se a pessoa faz isso com força. Essa pressão pode afetar o formato da córnea e provocar o astigmatismo."),
        //VisualDisease(name: "Miopia", info: "\n • A miopia é como um superpoder especial que faz com que você veja as coisas muito bem de perto, mas as coisas lá longe ficam meio embaçadas. Imagine que você é um detetive que adora procurar pistas bem de perto, como detalhes em um livro ou em um quebra-cabeça. Com a miopia, você é realmente bom nisso!\n\n • Mas, quando se trata de coisas distantes, como números na lousa da escola, esses podem parecer um pouco borrados ou difíceis de enxergar com clareza. É como se a visão do detetive ficasse um pouco fraca quando se trata de ver coisas longe.", prevent: "DICAS \n • Não fique muito tempo em frente à televisão, computador ou celular! As telas de aparelhos eletrônicos prejudica sua visão devido ao esforço excessivo de acomodação ocular, fazendo com que os músculos de nossos olhos façam o trabalho de forma repetitiva, provocando o início da miopia. \n A dica é descansar os olhos de vez em quando. E para as crianças, limitar o uso desses aparelhos. \n\n Pratique atividades ao ar livre! O contato com a luz natural ajuda no desenvolvimento do globo ocular. Para não termos riscos algum, é também recomendado a utilização de óculos de sol com proteção contra raios UV – ultravioletas -. \n • Crianças que não brincam na rua, comum em grandes metrópoles, têm maiores riscos de desenvolver miopia.",  filter: ""),
        VisualDisease(name: "Glaucoma", info: "\n • Imagine que seus olhos são como balões de ar. Dentro desses balões, há um líquido que precisa circular para manter seus olhos saudáveis. Agora, o glaucoma é como se esse líquido não conseguisse circular direito, e isso pode ser um problema.\n\n • Quando o líquido não consegue circular como deveria, ele começa a fazer pressão dentro do olho, como se estivesse enchendo o balão de ar. Isso é ruim porque pode fazer com que o olho fique inchado e machucar uma parte importante chamada nervo óptico.\n\n • O nervo óptico é como um cabo que leva mensagens do seu olho para o seu cérebro, permitindo que você veja as coisas. Se o nervo óptico ficar machucado, pode ser difícil enxergar bem, e é por isso que o glaucoma é sério.", prevent:"DICAS \n • Exames oftalmológicos regulares podem ajudar a detectar o glaucoma em seu estágio inicial, antes que ocorram danos significativos. \n\n • Levando em consideração que o glaucoma tende a ocorrer em famílias,  levante informações sobre o histórico familiar em relação à doença. \n\n • O exercício regular e moderado pode ajudar a prevenir o glaucoma, reduzindo a pressão ocular. Converse com seu médico sobre um programa de exercícios apropriado."),
        VisualDisease(name: "Catarata", info: "\n • A catarata é como uma janelinha embaçada nos seus olhos. Imagine que seus olhos são como câmeras que tiram fotos de tudo ao seu redor. Mas, quando você tem uma catarata, essa janelinha fica embaçada, como se tivesse uma nuvem na frente da câmera.\n\n • Isso acontece porque, dentro dos seus olhos, há uma parte chamada cristalino, que é como uma lente de óculos que ajuda a focar as imagens nítidas. Mas, com o tempo, o cristalino pode ficar embaçado, fazendo com que as coisas pareçam borradas ou difíceis de ver.", prevent:"DICAS \n • A exposição ao sol contínua e sem proteção causa danos aos olhos. O uso de óculos com proteção contra os raios UVA e AVB e o uso de chapéus e bonés também podem ajudar na prevenção da catarata. \n\n • Alguns medicamentos, principalmente corticóides, quando usados indevidamente e por tempo prolongado, propiciam o aparecimento de catarata e até mesmo o glaucoma \n\n • A alimentação saudável e rica em frutas, legumes e verduras é ótima para saúde não somente dos olhos como de todo o organismo. Dê preferência a alimentos que contenham nutrientes como ácidos graxos, ômega 3, luteína e zinco, que ajudam a prevenir a catarata e a degeneração macular. Eles podem ser encontrados nos seguintes alimentos: espinafre, couve, salmão, atum, ovos, nozes e feijão."),
        VisualDisease(name: "Daltonismo", info: "\n • O daltonismo é como se fosse uma mágica que faz com que algumas cores pareçam diferentes para as pessoas. Imagine que você está olhando para um arco-íris, aquele lindo arco de cores no céu depois da chuva. \n\n • Para a maioria das pessoas, as cores do arco-íris são bem definidas, como o vermelho, o laranja, o amarelo, o verde, o azul e o roxo. Mas para algumas pessoas com daltonismo, algumas dessas cores podem parecer um pouco confusas.\n\n • Por exemplo, o vermelho e o verde podem parecer muito parecidos, como se fossem irmãos gêmeos. Então, quando olham para um sinal de trânsito, como o semáforo, podem ter dificuldade em distinguir quando é a luz vermelha ou a luz verde.\nIsso acontece porque os olhos dessas pessoas têm uma maneira especial de ver as cores. Não é algo que elas possam controlar, é apenas como seus olhos funcionam.", prevent:"DICAS \n • Não é possível prevenir o daltonismo porém é possível corrigir através do uso de lentes que corrigem a falta de algumas cores."),
        VisualDisease(name: "Hipermetropia", info:"\n • A hipermetropia é como ter superpoderes especiais que fazem com que as coisas perto de você fiquem um pouco embaçadas, mas as coisas distantes são mais fáceis de ver. \n\n • Imagine que seus olhos são como uma câmera que tira fotos. Com a hipermetropia, essa câmera tem dificuldade em focar nas coisas que estão bem perto, como um livro ou um brinquedo que você está segurando nas mãos. Mas, quando você olha para algo mais longe, como a lousa da escola ou coisas do outro lado do quarto, elas parecem mais nítidas. \n\n • Isso acontece porque seus olhos não conseguem fazer com que a imagem das coisas próximas se forme direitinho na sua retina, que é como uma tela dentro dos seus olhos onde as imagens são mostradas.",prevent:"DICAS \n • Não existe uma forma de prevenir a hipermetropia, pois ela é causada por uma má formação no olho. Assim, o indivíduo precisa se adaptar ao uso contínuo de óculos ou lentes de grau ou, se preferir, realizar a cirurgia a laser para correção do erro refrativo."),
    ];
    let hueFilter = CIFilter(name: "CIHueAdjust")
    
    func hue() {
        hueFilter?.setValue(conditionAmount * 100 - 50, forKey: kCIInputAngleKey)
    }
    
    var body: some View {
        VStack{
            NavigationStack {
                GeometryReader { geometry in
                    ViewfinderView(image:  $model.viewfinderImage)
                        .blur(radius: blurAmount)
                        .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                        .scaledToFill()
                        .frame(width: 330, height: 330)
                        .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                    
                        .overlay(alignment: .top) {
                            topButtonsView()
                                .frame(height: geometry.size.height * Self.barHeightFactor)
                        }
                        .overlay(alignment: .bottom) {
                            bottomButtonsView()
                                .frame(height: geometry.size.height * Self.barHeightFactor)
                            
                        }
                        .overlay(alignment: .center)  {
                            
                            if(selectedFilter == "Astigmatismo") {
                                Color.black.opacity(conditionAmount * 0)
                                    .edgesIgnoringSafeArea(.all)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    .scaledToFill()
                                    .frame(width: 330, height: 330)
                                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                            } else if(selectedFilter == "Glaucoma") {
                                Color.black.opacity(conditionAmount)
                                    .blendMode(.overlay)
                                    .edgesIgnoringSafeArea(.all)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    .scaledToFill()
                                    .frame(width: 330, height: 330)
                                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                            } else if(selectedFilter == "Catarata") {
                                
                            } else if(selectedFilter == "Daltonismo") {
                                
                            } else if(selectedFilter == "Hipermetropia") {
                                
                            } else {
                                Color.black.opacity(conditionAmount)
                                    .edgesIgnoringSafeArea(.all)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    .scaledToFill()
                                    .frame(width: 330, height: 330)
                                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
                            }
                        }
                        .background(.black)
                }
                .task {
                    await model.camera.start()
                    await model.loadPhotos()
                    await model.loadThumbnail()
                }
                .navigationTitle("Camera")
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarHidden(true)
                .ignoresSafeArea()
                .statusBar(hidden: true)
            }
        }
    }
    
    private func topButtonsView() -> some View {
        VStack {
            ScrollView(.horizontal) {
                HStack {
                    ForEach(arrayVisualDiseases) { disease in
                        HStack {
                            NavigationLink(destination: VisionDetailsView(name: disease.name, info: disease.info, prevent: disease.prevent)) {
                                Image(systemName: "info.circle")
                            }
                            .padding(2)
                            .background(Color(.white))
                            .cornerRadius(25)
                            .foregroundColor(.blue)
                            
                            Button(action: {
                                selectedFilter = disease.name
                            }, label: {
                                Text(disease.name)
                                    .padding(10)
                                    .background(Color(.blue))
                                    .cornerRadius(25)
                                    .foregroundColor(.white)
                            })
                            
                        }
                    }.padding()
                }
            }.frame(height: 30)
        }
    }
    
    private func filters() -> some View {
        NavigationStack {
            VStack{
                HStack {
                    Slider(value: $conditionAmount, in: 0...1)
                    Text("Intensidade: \(conditionAmount, specifier: "%.2f")")
                        .foregroundColor(.white)
                }.padding()
                HStack {
                    Slider(value: $blurAmount, in: 0...10)
                    Text("Graus: \(blurAmount, specifier: "%.2f")")
                        .foregroundColor(.white)
                }.padding()
            }
        }
    }
    
    
    private func bottomButtonsView() -> some View {
        VStack {
            HStack{
                Spacer()
                Button {
                    model.camera.switchCaptureDevice()
                } label: {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundColor(.white)
                }
                .padding()
            }
            filters()
                .buttonStyle(.plain)
                .labelStyle(.iconOnly)
                .padding()
        }
    }
    
}


